<?php

namespace App\Http\Controllers;

use App\Models\Notification;
use App\Models\User;
use Illuminate\Http\Request;

class NotificationController extends Controller
{
    // User: Get my notifications (JSON for polling)
    public function index(Request $request)
    {
        $user = $request->user();
        $unreadCount = $user->notifications()->where('is_read', false)->count();
        $notifications = $user->notifications()
            ->where('is_read', false)
            ->latest()
            ->take(5)
            ->get()
            ->map(function ($n) {
                return [
                    'id' => $n->id,
                    'title' => $n->title,
                    'message' => $n->message,
                    'type' => $n->type,
                    'time_pretty' => $n->created_at->diffForHumans()
                ];
            });

        return response()->json([
            'unreadCount' => $unreadCount,
            'notifications' => $notifications
        ]);
    }

    // User: View all notifications page
    public function userIndex(Request $request)
    {
        $notifications = $request->user()->notifications()
            ->latest()
            ->paginate($request->input('per_page', 15));

        return view('dashboard.notifications.index', compact('notifications'));
    }

    public function markAllAsRead(Request $request)
    {
        $request->user()->notifications()->where('is_read', false)->update(['is_read' => true]);
        return back()->with('success', 'All notifications marked as read');
    }

    // Admin: Get all notifications
    public function adminIndex(Request $request)
    {
        $notifications = Notification::with('user')->latest()->paginate($request->input('per_page', 10));

        if ($request->expectsJson() || $request->is('api/*')) {
            return $notifications;
        }

        $users = User::all();
        return view('admin.notifications.index', compact('notifications', 'users'));
    }

    // User: Toggle read/unread status
    public function markAsRead(Request $request, $id)
    {
        $notification = $request->user()->notifications()->findOrFail($id);
        $notification->update(['is_read' => !$notification->is_read]);
        return response()->json([
            'message' => $notification->is_read ? 'Marked as read' : 'Marked as unread',
            'is_read' => $notification->is_read
        ]);
    }

    // Admin: Send Notification
    public function store(Request $request)
    {
        $request->validate([
            'user_id' => 'required', // Can be "all" or specific ID
            'title' => 'required|string|max:255',
            'message' => 'required|string',
            'type' => 'in:info,success,warning,error'
        ]);

        if ($request->user_id === 'all') {
            $users = User::where('role', '!=', 'admin')->get();
            foreach ($users as $user) {
                Notification::create([
                    'user_id' => $user->id,
                    'title' => $request->title,
                    'message' => $request->message,
                    'type' => $request->type ?? 'info',
                    'is_read' => false
                ]);
            }
            return redirect()->back()->with('success', 'Notification sent to all users');
        }

        $notification = Notification::create([
            'user_id' => $request->user_id,
            'title' => $request->title,
            'message' => $request->message,
            'type' => $request->type ?? 'info',
            'is_read' => false
        ]);

        return redirect()->back()->with('success', 'Notification sent successfully');
    }
    public function destroy($id)
    {
        Notification::destroy($id);
        return redirect()->back()->with('success', 'Notification deleted successfully');
    }
}
